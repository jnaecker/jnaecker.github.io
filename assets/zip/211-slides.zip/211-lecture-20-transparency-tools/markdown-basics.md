---
title: "Markdown Basics"
author: "Jeffrey Naecker"
date: "4/17/2018"
output:
  pdf_document: default
  html_document: default
  word_document: default
---


# Introduction

This is a list:

- item 	
- another item
- another item

> A quote by some famous person.

# Theory

Here's some math: $$x=\int y^2 dy$$

# Design

A footnote[^1].

[^1]: The footnote text

A [link](http://programminghistorian.org/lessons/sustainable-authorship-in-plain-text-using-pandoc-and-markdown).

# Results

![Hisogram of results](fig.png)

# Conclusion