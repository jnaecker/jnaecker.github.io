# This is a comment; it won't be run as code.

library(ggplot2)

## basic math in R 

2 + 2

3 + 4

## variables

## assignment operator (think =)
x <- 6

x

## vectors 

vector <- c(1, 2, 3, 4, 50)

## basic stats functions

mean(vector)

sd(vector)




